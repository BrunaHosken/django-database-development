# Django specific settings
import inspect
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
from django.db import connection
# Ensure settings are read
from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()

from crud.models import *
from datetime import date


# Your code starts from here:
instructor_yan = Instructor.objects.get(first_name="Yan")
print("1. Encontre um único instrutor com o primeiro nome `Yan`")
print(instructor_yan)
print("\n")

try:
    instructor_andy = Instructor.objects.get(first_name="Andy")
except Instructor.DoesNotExist:
    print("2. Tente encontrar um instrutor não existente com o primeiro nome `Andy`")
    print("O instrutor Andy não existe")

print("\n")
part_time_instructors = Instructor.objects.get(full_time=False)
print("3. Encontre todos os instrutores de meio período: ")
print(part_time_instructors)

print("\n")
part_time_instructors = Instructor.objects.get(full_time=True,first_name__startswith="Y", total_learners__gt = 30000 )
print("4. Encontre todos os instrutores de tempo integral com o primeiro nome começando com `Y` e contagem de alunos maior que 30000 ")
print(part_time_instructors)